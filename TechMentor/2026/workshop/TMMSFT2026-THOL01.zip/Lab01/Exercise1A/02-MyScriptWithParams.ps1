param(
    [datetime] $EventDate = '03/03/2026',
    [string]   $Presenter = 'Sean',
    [string]   $Subject   = 'how to work with PowerShell modules'
)

if ($EventDate -eq [datetime]::Today ) {
    Write-Host -Object ('Today the {0}, {1} shows "{2}"!' -f @(
            '{0:d.MM.yyyy}' -f $EventDate
            $Presenter
            $Subject
        )
    )
} else {
    Write-Host "It's not today!"
}