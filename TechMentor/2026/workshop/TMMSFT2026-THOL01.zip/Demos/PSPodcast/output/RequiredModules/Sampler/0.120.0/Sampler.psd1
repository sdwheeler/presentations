@{
    # Script module or binary module file associated with this manifest.
    RootModule        = 'Sampler.psm1'

    # Version number of this module.
    ModuleVersion     = '0.120.0'

    # Supported PSEditions
    # CompatiblePSEditions = @('Desktop','Core') # Removed to support PS 5.0

    # ID used to uniquely identify this module
    GUID              = 'b59b8442-9cf9-4c4b-bc40-035336ace573'

    # Author of this module
    Author            = 'Gael Colas'

    # Company or vendor of this module
    CompanyName       = 'SynEdgy Limited'

    # Copyright statement for this module
    Copyright         = '(c) Gael Colas. All rights reserved.'

    # Description of the functionality provided by this module
    Description       = 'Sample Module with Pipeline scripts and its Plaster template to create a module following some of the community accepted practices.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion = '5.0'

    # Modules that must be imported into the global environment prior to importing this module
    RequiredModules   = @(
        'Plaster'
    )

    # Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
    NestedModules     = @()

    # Functions to export from this module
    FunctionsToExport = @('Add-Sample','Convert-SamplerHashtableToString','Get-BuiltModuleVersion','Get-ClassBasedResourceName','Get-CodeCoverageThreshold','Get-MofSchemaName','Get-OperatingSystemShortName','Get-PesterOutputFileFileName','Get-Psm1SchemaName','Get-SamplerAbsolutePath','Get-SamplerBuildVersion','Get-SamplerBuiltModuleBase','Get-SamplerBuiltModuleManifest','Get-SamplerCodeCoverageOutputFile','Get-SamplerCodeCoverageOutputFileEncoding','Get-SamplerModuleInfo','Get-SamplerModuleRootPath','Get-SamplerProjectBuildInfo','Get-SamplerProjectName','Get-SamplerSourcePath','Get-SamplerWorkspaceBuiltModulePath','Get-SamplerWorkspaceLinkedModuleRoot','Invoke-SamplerGit','Merge-JaCoCoReport','New-SampleModule','New-SamplerJaCoCoDocument','New-SamplerPipeline','New-SamplerWorkspaceModuleLink','Out-SamplerXml','Set-SamplerPSModulePath','Split-ModuleVersion','Update-JaCoCoStatistic')

    # Cmdlets to export from this module
    CmdletsToExport   = ''

    # Variables to export from this module
    VariablesToExport = ''

    # Aliases to export from this module
    AliasesToExport   = '*'

    # List of all modules packaged with this module
    ModuleList        = @()

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData       = @{
        PSData = @{
            # Extension for Plaster Template discoverability with `Get-PlasterTemplate -IncludeInstalledModules`
            Extensions   = @(
                @{
                    Module         = 'Plaster'
                    minimumVersion = '1.1.3'
                    Details        = @{
                        TemplatePaths = @(
                            'Templates\Classes'
                            'Templates\ClassResource'
                            'Templates\Composite'
                            'Templates\Enum'
                            'Templates\MofResource'
                            'Templates\PrivateFunction'
                            'Templates\PublicCallPrivateFunctions'
                            'Templates\PublicFunction'
                            'Templates\Sampler'
                        )
                    }
                }
            )

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('Template', 'pipeline', 'plaster', 'DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource', 'Windows', 'MacOS', 'Linux')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/gaelcolas/Sampler/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/gaelcolas/Sampler'

            # A URL to an icon representing this module.
            IconUri      = 'https://raw.githubusercontent.com/gaelcolas/Sampler/main/Sampler/assets/sampler.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [0.120.0] - 2026-07-14

### Added

- New `Copilot` Plaster template under `Sampler/Templates/Copilot/` that scaffolds GitHub Copilot instruction files and a `validate-changes` skill into any Sampler-based module. Available via `Add-Sample -Sample Copilot` and as a `copilot` feature option in `New-SampleModule` (CustomModule and CompleteSample).
- New `TypeAccelerators` Plaster template under `Sampler/Templates/TypeAccelerators/` that scaffolds a `suffix.ps1` exporting classes as type accelerators, the workaround pattern for PowerShell modules being unable to export classes directly. Available via `Add-Sample -Sample TypeAccelerators -SourceDirectory <path> -ExportableTypeName <ClassName>`. The generated file exposes two author-controlled lists (`$TypesToExportAsIs` for bare-name exports, `$TypesToExportWithNamespace` for `<ModuleName>.<ClassName>` exports) so each class''s export name is a deliberate per-class choice. If an accelerator with the same name is already registered (for example after a `-Force` re-import during development), it is brute-force overridden (removed and re-registered) with a `Write-Verbose` message, rather than throwing.
- `TypeAccelerators` is now also available as a `Features` option in `New-SampleModule` (`CustomModule`, requires `Classes` and `SampleScripts`, or `All`) and is included unconditionally in the `CompleteSample` module type, scaffolding a `suffix.ps1` that exports the sample `Class1` as a type accelerator. `New-SampleModule`''s generated `build.yaml` also automatically uncomments `suffix: suffix.ps1` whenever this `suffix.ps1` file is scaffolded, so `ModuleBuilder` actually merges it in without extra manual steps.
- New `Type-Accelerators` wiki page (`Sampler/WikiSource/Type-Accelerators.md`, linked from `Home.md`) documenting the `TypeAccelerators` template, its design choices, and how to consume exported types from another module, referencing https://synedgy.com/powershell-modules-exporting-classes/ for background.
- New `export-class-type-accelerator` Copilot skill (`Sampler/Templates/Copilot/skills/export-class-type-accelerator/`) that walks through scaffolding or extending a module''s `suffix.ps1` type-accelerator exports and explicitly verifies `build.yaml` has `suffix: suffix.ps1` uncommented, since that wiring step fails silently (no error, warning, or test failure) if missed. Scaffolded alongside `classes-and-type-accelerators.instructions.md` whenever `HasClasses`/the `Classes` feature is enabled, via `Add-Sample -Sample Copilot`, `New-SampleModule` (`copilot` + `Classes` features, or `CompleteSample`).
- New `Link_Local_Workspace_Dependencies` build task and supporting public functions (`Get-SamplerWorkspaceLinkedModuleRoot`, `Get-SamplerWorkspaceBuiltModulePath`, `New-SamplerWorkspaceModuleLink`) for linking sibling workspace module build outputs into the local module output path when working across related repos in a multi-repo workspace. Configure via `WorkspaceModules` in `build.yaml`.
- `Clean` task now preserves `output\agentic\` across builds (in addition to `RequiredModules`), providing a stable location for build and test log files that survive clean cycles. The subfolder name is configurable via the `AgentOutputSubdirectory` parameter (default `''agentic''`; set to empty string to disable the exclusion).
- `package_psresource_nupkg` tasks that recursively packs dependencies, ignoring `ExternalDependencies` using `PSResourceGet` module.

### Fixed

- Updated `Mock` setups across `tests/Unit/tasks/*.build.Tests.ps1`,
  `tests/Unit/TestHelpers/MockSetSamplerTaskVariable.ps1`, and
  `tests/Unit/scripts/Set-SamplerTaskVariable.Tests.ps1` for compatibility with
  Pester 6.0.0, which removed the previous "fall through to the real command"
  behavior for a `Mock -ParameterFilter` that did not match a call; such calls
  now throw `No mock for command ''<name>'' matched the call` instead of silently
  invoking the real command. Added default (no-filter) fallback mocks for
  commands like `Get-SamplerAbsolutePath`, `Get-Command`, `Get-Content`,
  `Test-Path`, `Get-ChildItem`, and `Import-Module` so calls not covered by a
  test''s specific `-ParameterFilter` resolve sensibly, without weakening any
  test''s original assertions. Also replaced the removed `Assert-MockCalled`
  cmdlet with `Should -Invoke` in `SetPsModulePath.build.Tests.ps1`, and
  accounted for Pester 6.0.0 dropping the legacy `Invoke-Pester`
  `-OutputFile`/`-OutputFormat` parameters used by the Pester-4 code path in
  `Invoke-Pester.pester.build.Tests.ps1`. No production source files were
  changed; this is purely a test-suite compatibility fix.
- `Sampler/Templates/Build/build.yaml.template` (scaffolded by `New-SampleModule`
  and `Add-Sample -Sample Build`) now generates the current nested
  `Pester.Configuration` (`Run`/`Output`/`Filter`/`CodeCoverage`/`TestResult`)
  schema instead of the deprecated flat `Pester.OutputFormat`/`Pester.Script`/
  `Pester.CodeCoverageThreshold`/`Pester.CodeCoverageOutputFile` keys, matching
  the structure Sampler itself uses in its own `build.yaml`. The old flat keys
  still work (`Invoke-Pester.pester.build.ps1` keeps a deprecation fallback and
  prints migration guidance), but new modules scaffolded from the template were
  being generated with an already-deprecated configuration shape. Fixes #587.
- `Fail_Build_If_Pester_Tests_Failed` and the `DscResource.Test` build task now fail
  the build when a Pester 5 run reports failed blocks or failed containers (for
  example a discovery failure such as an empty `-ForEach`), not only when
  `FailedCount` is greater than zero. Such container/discovery failures leave
  `FailedCount` at `0`, so the previous gate let them pass as a green build. The gate
  now uses the Pester 5 `Result` property and falls back to `FailedCount` for
  Pester 4 result objects.
- `Create_Release_Git_Tag` and `Create_Changelog_Branch` tasks now read `MainGitBranch` from `BuildInfo.GitConfig.MainGitBranch` in `build.yaml` when not set as a task parameter or InvokeBuild property. The resolution order is: task parameter -> `build.yaml` `GitConfig.MainGitBranch` -> default `''main''`.
- `Create_Release_Git_Tag` and `Create_Changelog_Branch` tasks no longer call `git config user.name` or `git config user.email` when `GitConfigUserName` or `GitConfigUserEmail` are not set (empty/null), allowing the existing global or system git identity to be used without being overwritten with an empty value.
- `Create_Release_Git_Tag` and `Create_Changelog_Branch` tasks no longer wrap the `http.extraheader` value in literal double quotes when authenticating a `git pull`/`push` with `BasicAuthPAT`. Since the argument is passed directly to `git` (not through a shell), the quote characters were previously sent as part of the literal `AUTHORIZATION` header value, which some servers (e.g. Apache) rejected with a `400 Bad Request`. The `http.sslbackend=schannel` git config, which is only supported by Git for Windows, is now only applied when running on Windows so the same tasks work correctly on Linux and macOS.
- The `Build` Plaster template (`build.yaml.template`) now scaffolds a `GitConfig:` section with `MainGitBranch` pre-populated from the Plaster parameter entered during scaffolding, and `UserName`/`UserEmail` as commented-out examples.
- `New-SampleModule` now accepts `-GitHubOwner` and `-GitHubOwnerDscCommunity` parameters so the GitHub owner can be specified non-interactively when scaffolding GitHub-enabled or `dsccommunity` modules.
- `New-SampleModule` now forwards empty-string parameter values (such as `ModuleDescription = ''''`) to Plaster instead of silently dropping them, eliminating unexpected interactive prompts when all parameters are splatted.
- `New-SampleModule` documents the `CustomModule` `ModuleType` and the new `MainGitBranch` parameter.
- `New-SampleModule` `ModuleType` `ValidateSet` now includes `CustomModule`.
- `New-SampleModule` exposes a `MainGitBranch` parameter (defaults to `main`) for templates that configure a default Git branch.
- GitHub Copilot guidance for the project under `.github/`:
  - `copilot-instructions.md` documenting build/test/quality commands, the mandatory `./build.ps1` entry point, high-level architecture, key conventions (changelog discipline, `-ErrorAction ''Ignore''` preference, cross-platform/cross-version PS5.1+PS7 support), guidance for running long builds without hanging the agent shell (always tee output to a log file), and how to extract test failures from the Pester NUnit XML and HQRM CliXml result files.
  - Per-area `instructions/*.instructions.md` files for public functions, private functions, Plaster templates, build tasks, and Pester tests.
  - `agents/sampler-maintainer.md` agent definition and the `skills/validate-changes` skill that picks the smallest useful test scope and surfaces XML-based failure diagnostics.

### Changed

- `New-SampleModule` no longer splits `ModuleType` and `Features` into separate parameter sets, so both can be supplied in the same invocation.
- Pester task setup now still supports repository-only test runs without a prebuilt module, but fails fast when a PowerShell module test workflow is invoked before the module output has been built.
- Documented the separation between source kind and artifact context in build-task guidance, clarified module-versus-non-module version fallback rules, and expanded the README with pipeline-shape documentation for module, alternate-artifact, and standalone repository flows.
- Added `Get-SamplerProjectBuildInfo` and updated Pester build tasks to use its `BuildType`/`HasBuiltOutput` project model directly instead of Pester-specific setup/import/identity wrapper functions.
- Pinned `ModuleBuilder` to `3.1.8` in `RequiredModules.psd1` because newer versions break Sampler task alias registration during tests.
- Temporarily skip the `SimpleModule` integration tests that depend on building'

            Prerelease   = ''
        } # End of PSData hashtable
    } # End of PrivateData hashtable
}
