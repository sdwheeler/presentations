#Region '.\Public\Find-PSPodcastEpisode.ps1' -1

function Find-PSPodcastEpisode {
    <#
    .SYNOPSIS
    Retrieve and optionally download episodes from the PowerShell Podcast.

    .DESCRIPTION
    This function fetches the RSS feed of the PowerShell Podcast and returns a list of episodes that
    match the specified search string. The command matches terms in the title and description of the
    episode.

    .PARAMETER Find
    A search string to filter episodes by title or description. This can be a regular expression.

    .EXAMPLE
    # List episodes with "Azure" in the title or description
    Find-PSPodcastEpisode -Find Azure

    .INPUTS
    System.String

    .OUTPUTS
    System.Management.Automation.PSCustomObject

    .LINK
    https://powershellpodcast.podbean.com/

    #>

    [CmdletBinding()]
    param (
        [Parameter(Position = 0, Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [SupportsWildcards()]
        [string]$Find
    )

    begin {
        if (-not $PSBoundParameters.ContainsKey('Verbose')) {
            $Verbose = $false
        }
        $invokeRestMethodSplat = @{
            Uri            = 'https://feed.podbean.com/powershellpodcast/feed.xml'
            ProgressAction = 'SilentlyContinue'
            ErrorAction    = 'SilentlyContinue'
            Verbose        = $Verbose
        }
        $feed = Invoke-RestMethod @invokeRestMethodSplat
        if ($null -eq $feed) {
            Write-Error "Failed to retrieve the podcast feed $($invokeRestMethodSplat.Uri)."
            return
        }
    }
    process {
        $feed |
            Where-Object { $_.title -match $Find -or
                $_.description.'#cdata-section' -match $Find } |
            ForEach-Object {
                $duration = [timespan]::new(0, 0, $_.duration) # hrs,min,sec

                [pscustomobject]@{
                    episode     = [int]$_.episode
                    pubDate     = '{0:yyyy-MM-dd}' -f [datetime]$_.pubDate
                    duration    = $duration.ToString()
                    title       = $_.title[0]
                }
            }
    }
}
#EndRegion '.\Public\Find-PSPodcastEpisode.ps1' 68
#Region '.\Public\Get-PSPodcast.ps1' -1

function Get-PSPodcast {
    <#
    .SYNOPSIS
    Retrieve and optionally download episodes from the PowerShell Podcast.

    .DESCRIPTION
    This function fetches the RSS feed of the PowerShell Podcast and lists all episodes.

    .EXAMPLE
    # List all episodes
    Get-PSPodcast

    .INPUTS
    None

    .OUTPUTS
    System.Management.Automation.PSCustomObject

    .LINK
    https://powershellpodcast.podbean.com/

    #>

    [CmdletBinding()]
    param ()

    begin {
        if (-not $PSBoundParameters.ContainsKey('Verbose')) {
            $Verbose = $false
        }
        $invokeRestMethodSplat = @{
            Uri            = 'https://feed.podbean.com/powershellpodcast/feed.xml'
            ProgressAction = 'SilentlyContinue'
            ErrorAction    = 'SilentlyContinue'
            Verbose        = $Verbose
        }
        $feed = Invoke-RestMethod @invokeRestMethodSplat
        if ($null -eq $feed) {
            Write-Error "Failed to retrieve the podcast feed $($invokeRestMethodSplat.Uri)."
            return
        }
    }
    process {

        $feed | ForEach-Object {
            $duration = [timespan]::new(0,0,$_.duration) # hrs,min,sec

            [pscustomobject]@{
                episode  = [int]$_.episode
                pubDate  = '{0:yyyy-MM-dd}' -f [datetime]$_.pubDate
                duration = $duration.ToString()
                title    = $_.title[0]
            }
        }
    }
}
#EndRegion '.\Public\Get-PSPodcast.ps1' 57
#Region '.\Public\Get-PSPodcastEpisode.ps1' -1

function Get-PSPodcastEpisode {
    <#
    .SYNOPSIS
    Retrieve and optionally download episodes from the PowerShell Podcast.

    .DESCRIPTION
    This function fetches the RSS feed of the PowerShell Podcast and returns the specified episode.

    .PARAMETER Episode
    The episode number to fetch.

    .PARAMETER OutFolder
    The folder where the episode will be saved. The folder must exist.

    .EXAMPLE
    # Download episode number 50 to the current directory
    Get-PSPodcastEpisode -Episode 50

    .EXAMPLE
    # Download episode number 50 to a specified folder
    Get-PSPodcastEpisode -Episode 50 -OutFolder "C:\Podcasts"

    .INPUTS
    System.Int32

    .OUTPUTS
    System.Management.Automation.PSCustomObject

    .OUTPUTS
    System.IO.FileInfo

    .NOTES
    The output folder must exist.

    .LINK
    https://powershellpodcast.podbean.com/

    #>

    [CmdletBinding()]
    param (
        [Parameter(Position = 0, Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('Number')]
        [int]$Episode,

        [Parameter(Position = 1, HelpMessage = 'Enter path of an existing folder.')]
        [ValidateScript({ Test-Path $_ -PathType Container },
            ErrorMessage = 'OutFolder must be a valid directory path.')]
        [ValidateNotNullOrWhiteSpace()]
        [string]$OutFolder
    )

    begin {
        if (-not $PSBoundParameters.ContainsKey('Verbose')) {
            $Verbose = $false
        }
        if (-not $PSBoundParameters.ContainsKey('ProgressAction')) {
            $ProgressAction = 'Continue'
        }
        $invokeRestMethodSplat = @{
            Uri            = 'https://feed.podbean.com/powershellpodcast/feed.xml'
            ProgressAction = 'SilentlyContinue'
            ErrorAction    = 'SilentlyContinue'
            Verbose        = $Verbose
        }
        $feed = Invoke-RestMethod @invokeRestMethodSplat
        if ($null -eq $feed) {
            Write-Error "Failed to retrieve the podcast feed $($invokeRestMethodSplat.Uri)."
            return
        }
    }
    process {
        $feed |
            Where-Object { $_.episode -eq $Episode } |
            ForEach-Object {
                $duration = [TimeSpan]::new(0,0,$_.duration) # hrs,min,sec
                $epiUrl = $_.enclosure.url
                $fileExtension = ($epiUrl -split '\.')[-1]

                $ep = [pscustomobject]@{
                    episode  = [int]$_.episode
                    pubDate  = '{0:yyyy-MM-dd}' -f [datetime]$_.pubDate
                    duration = $duration.ToString()
                    title    = $_.title[0]
                    description = $_.description.'#cdata-section'
                }
                if ($OutFolder -ne '') {
                    $outfile = Join-Path $OutFolder "PowerShell_Podcast_$($_.episode).$fileExtension"
                    Write-Verbose "Downloading episode $($_.episode) to $outfile"
                    Invoke-RestMethod -Uri $epiUrl -OutFile $outfile -Verbose:$Verbose -ProgressAction:$ProgressAction
                    Get-ChildItem -LiteralPath $outfile
                } else {
                    $ep
                }
            }
    }
}
#EndRegion '.\Public\Get-PSPodcastEpisode.ps1' 98

